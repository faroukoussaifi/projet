package entities;

public final class Terrestrial extends Animal{
    //att
    private int nbrLegs;
}
